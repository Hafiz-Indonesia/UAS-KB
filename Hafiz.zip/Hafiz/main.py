usia = int(input("Masukkan usia (dalam tahun): "))
tekanan_darah = int(input("Masukkan tekanan darah (dalam mmHg): "))
denyut_jantung = int(input("Masukkan denyut jantung (dalam denyut per menit): "))

batas_usia = 30
batas_tekanan_darah = 120
batas_denyut_jantung = 80

hasil_seleksi = ''

if usia <= batas_usia and tekanan_darah <= batas_tekanan_darah and denyut_jantung >= batas_denyut_jantung:
    hasil_seleksi = "Lolos seleksi beasiswa"
else:
    hasil_seleksi = "Tidak lolos seleksi beasiswa"

print("Hasil seleksi:", hasil_seleksi)

input("Tekan Enter untuk keluar...")